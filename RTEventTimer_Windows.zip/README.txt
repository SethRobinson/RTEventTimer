RTEventTimer - Real-Time Event Timer 
===================================== 
 
To run the timer: 
1. Double-click RTEventTimer.exe 
2. The timer will appear as an overlay on your screen 
 
Controls: 
- Click and drag anywhere to move the timer 
- Click the gear icon to open settings 
- Click the X button to close 
 
Note: You can customize the sounds and background by replacing files in the Assets folder: 
- background.png: Timer background image (1920x270 pixels with transparency) 
- timer_finished.wav: Sound that plays when timer reaches zero 
- button1.wav: Sound that plays when buttons are clicked 
